import React, { createContext, useState, useContext, useEffect } from "react";
import { authService } from "../services/authService";

// ============================================
// MODULE ACCESS DEFINITIONS
// ============================================
export const MODULES = {
    DASHBOARD: 'dashboard',
    LEAVE: 'leave',
    EMPLOYEES: 'employees',
    CUSTOMERS: 'customers',
    RECEIPTS: 'receipts',
    INSTALLMENT: 'installment',
    INVENTORY: 'inventory',
    TAX_RATES: 'tax_rates',
    CASH_BANK: 'cash_bank',
    PROJECTS: 'projects',
    PAYMENT_TYPES: 'payment_types',
    ATTENDANCE: 'attendance',
    MOBILE_CHECKIN: 'mobile_checkin',
};

// ✅ Role-based module access
export const ROLE_MODULE_ACCESS = {
    // Employee: Only Leave module
    employee: {
        modules: [MODULES.DASHBOARD, MODULES.LEAVE],
        routes: [
            '/dashboard',
            '/leave-dashboard',
            '/leave/*',
            '/LeaveTypes',
            '/LeaveRequests',
            '/LeaveApply',
            '/ApplyLeave',
            '/leave/balance',
        ],
        // ✅ Employee permissions
        permissions: {
            canApplyForSelf: true,
            canApplyForOthers: false,
            canViewAllRequests: false,
            canApproveRequests: false,
            canViewTeamMembers: false,
        }
    },
    // Custodian: Leave + Employees (Team Management)
    custodian: {
        modules: [MODULES.DASHBOARD, MODULES.LEAVE, MODULES.EMPLOYEES],
        routes: [
            '/dashboard',
            '/leave-dashboard',
            '/leave/*',
            '/LeaveTypes',
            '/LeaveRequests',
            '/LeaveApply',
            '/ApplyLeave',
            '/leave/balance',
            '/employees',
            '/team/*',
        ],
        // ✅ Custodian permissions
        permissions: {
            canApplyForSelf: true,
            canApplyForOthers: true,
            canViewAllRequests: false,
            canApproveRequests: false,
            canViewTeamMembers: true,
            canManageTeam: true,
        }
    },
    // HR: Leave + Employees
    HR: {
        modules: [MODULES.DASHBOARD, MODULES.LEAVE, MODULES.EMPLOYEES],
        routes: [
            '/dashboard',
            '/leave-dashboard',
            '/leave/*',
            '/LeaveTypes',
            '/LeaveRequests',
            '/LeaveApply',
            '/ApplyLeave',
            '/leave/balance',
            '/employees',
            '/leave/approval/*',
            '/leave/reports/*',
        ],
        // ✅ HR permissions
        permissions: {
            canApplyForSelf: true,
            canApplyForOthers: false, // HR applies only for themselves
            canViewAllRequests: true,
            canApproveRequests: true,
            canViewTeamMembers: true,
            canManageTeam: true,
            canViewReports: true,
        }
    }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

export const isRouteAllowed = (user, path) => {
    if (!user) return false;
    
    const access = ROLE_MODULE_ACCESS[user.Role];
    if (!access) return false;
    
    return access.routes.some(route => {
        if (route === '/*') return true;
        if (route.endsWith('/*')) {
            const baseRoute = route.replace('/*', '');
            return path.startsWith(baseRoute);
        }
        return path === route;
    });
};

export const isModuleAccessible = (user, moduleName) => {
    if (!user) return false;
    const access = ROLE_MODULE_ACCESS[user.Role];
    if (!access) return false;
    return access.modules.includes(moduleName);
};

export const hasRole = (user, role) => {
    if (!user) return false;
    return user.Role === role;
};

// ✅ Check if user has specific permission
export const hasPermission = (user, permission) => {
    if (!user) return false;
    const access = ROLE_MODULE_ACCESS[user.Role];
    if (!access) return false;
    return access.permissions[permission] || false;
};

// ============================================
// AUTH CONTEXT
// ============================================

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        const token = authService.getToken();
        const userData = authService.getUser();
        
        if (token && userData) {
            setUser(userData);
            setIsAuthenticated(true);
        }
        setLoading(false);
    }, []);

    const login = async (email, password) => {
        try {
            const response = await authService.login(email, password);
            if (response.status === "success") {
                const userData = response.data.user;
                setUser(userData);
                setIsAuthenticated(true);
                return { success: true };
            }
            return { success: false, message: response.message || "Login failed" };
        } catch (error) {
            console.error("Login error:", error);
            return {
                success: false,
                message: error.response?.data?.message || "Login failed"
            };
        }
    };

    
const loginWithEmployeeCode = async (employeeCode, password) => {
    try {
        const response = await authService.loginWithEmployeeCode(employeeCode, password);
        console.log("AuthContext - Login response:", response);
        
        if (response.status === "success") {
            const userData = response.data.user;
            console.log("AuthContext - Setting user:", userData);
            
            // ✅ Make sure user is set in state
            setUser(userData);
            setIsAuthenticated(true);
            
            // ✅ Also store in localStorage (authService already does this)
            // but let's verify
            localStorage.setItem("token", response.data.token);
            localStorage.setItem("user", JSON.stringify(userData));
            
            return { success: true };
        }
        return { success: false, message: response.message || "Login failed" };
    } catch (error) {
        console.error("Login error in AuthContext:", error);
        return {
            success: false,
            message: error.response?.data?.message || "Login failed"
        };
    }
};

    const logout = () => {
        authService.logout();
        setUser(null);
        setIsAuthenticated(false);
    };

    // ============================================
    // ROLE-BASED ACCESS FUNCTIONS
    // ============================================

    const getRoleDisplay = () => {
        const roleMap = {
            'employee': 'Employee',
            'custodian': 'Custodian',
            'HR': 'HR'
        };
        return roleMap[user?.Role] || user?.Role || 'Unknown';
    };

    const isEmployee = () => user?.Role === 'employee';
    const isCustodian = () => user?.Role === 'custodian';
    const isHR = () => user?.Role === 'HR';
    
    const canApplyForOthers = () => {
        return hasPermission(user, 'canApplyForOthers');
    };

    const getTeamMembers = () => {
        return user?.teamMembers || [];
    };

    const canAccessModule = (moduleName) => {
        return isModuleAccessible(user, moduleName);
    };

    const canAccessRoute = (path) => {
        return isRouteAllowed(user, path);
    };

    const getAccessibleModules = () => {
        if (!user) return [];
        const access = ROLE_MODULE_ACCESS[user.Role];
        return access?.modules || [];
    };

    // ✅ Check if user can approve/reject leave requests
    const canApproveLeave = () => {
        return hasPermission(user, 'canApproveRequests');
    };

    // ✅ Check if user can view all leave requests
    const canViewAllRequests = () => {
        return hasPermission(user, 'canViewAllRequests');
    };

    const value = {
        user,
        loading,
        isAuthenticated,
        login,
        loginWithEmployeeCode,
        logout,
        // Role functions
        getRoleDisplay,
        isEmployee,
        isCustodian,
        isHR,
        canApplyForOthers,
        getTeamMembers,
        canAccessModule,
        canAccessRoute,
        getAccessibleModules,
        canApproveLeave,
        canViewAllRequests,
        hasPermission,
        // Convenience
        role: user?.Role,
        isEmployeeRole: user?.Role === 'employee',
        isCustodianRole: user?.Role === 'custodian',
        isHRRole: user?.Role === 'HR'
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
};