import axios from "axios";

const getApiUrl = () => {
    if (process.env.REACT_APP_API_URL) {
        return process.env.REACT_APP_API_URL;
    }
    const hostname = window.location.hostname;
    if (hostname !== "localhost" && hostname !== "127.0.0.1") {
        return `http://${hostname}:5000/api`;
    }
    return "http://localhost:5000/api";
};

const API_URL = getApiUrl();
console.log("🔗 API URL configured:", API_URL);

// ✅ FIXED: Create axios instance
const api = axios.create({
    baseURL: API_URL,
    headers: {
        "Content-Type": "application/json"
    },
    timeout: 30000
});

// ✅ FIXED: Request interceptor - ALWAYS add token
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem("token");
        console.log(`🔐 Request to ${config.url}, Token: ${token ? '✅ Present' : '❌ Missing'}`);
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
            console.log(`🔐 Authorization header set: Bearer ${token.substring(0, 20)}...`);
        } else {
            console.warn("⚠️ No token found in localStorage for request to", config.url);
        }
        return config;
    },
    (error) => {
        console.error("❌ Request interceptor error:", error);
        return Promise.reject(error);
    }
);

// ✅ FIXED: Response interceptor - Only logout on 401
api.interceptors.response.use(
    (response) => {
        console.log(`✅ Response from ${response.config.url}: ${response.status}`);
        return response;
    },
    (error) => {
        console.error("❌ Response error:", error.response?.status, error.response?.data);
        
        // ✅ Only redirect to login for 401 errors
        if (error.response?.status === 401) {
            console.warn("⚠️ 401 Unauthorized - Redirecting to login");
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            if (!window.location.pathname.includes('/login')) {
                window.location.href = "/login";
            }
        }
        return Promise.reject(error);
    }
);

// ============================================
// AUTH FUNCTIONS
// ============================================

export const loginWithEmployeeCode = async (employeeCode, password) => {
    try {
        console.log("🔐 Attempting login with employee code:", employeeCode);
        const response = await api.post("/auth/login/employee-code", { employeeCode, password });
        console.log("📡 API Response:", response.data);
        
        if (response.data.status === "success") {
            if (response.data.data.token) {
                localStorage.setItem("token", response.data.data.token);
                console.log("✅ Token stored in localStorage");
            }
            if (response.data.data.user) {
                localStorage.setItem("user", JSON.stringify(response.data.data.user));
                console.log("✅ User data stored in localStorage");
            }
        }
        return response.data;
    } catch (error) {
        console.error("❌ Login error:", error.message);
        throw error;
    }
};

export const login = async (email, password) => {
    try {
        console.log("🔐 Attempting login with email:", email);
        const response = await api.post("/auth/login", { email, password });
        if (response.data.status === "success") {
            if (response.data.data.token) {
                localStorage.setItem("token", response.data.data.token);
            }
            if (response.data.data.user) {
                localStorage.setItem("user", JSON.stringify(response.data.data.user));
            }
        }
        return response.data;
    } catch (error) {
        console.error("❌ Login error:", error.message);
        throw error;
    }
};

export const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    console.log("👋 Logged out");
};

export const getToken = () => {
    const token = localStorage.getItem("token");
    console.log(`🔐 getToken: ${token ? '✅ Token exists' : '❌ No token'}`);
    return token;
};

export const getUser = () => {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
};

export const isAuthenticated = () => {
    const token = localStorage.getItem("token");
    const isAuth = !!token;
    console.log(`🔐 isAuthenticated: ${isAuth ? '✅ Yes' : '❌ No'}`);
    return isAuth;
};

// ✅ Export the api instance
export default api;

export const authService = {
    login,
    loginWithEmployeeCode,
    logout,
    getToken,
    getUser,
    isAuthenticated
};